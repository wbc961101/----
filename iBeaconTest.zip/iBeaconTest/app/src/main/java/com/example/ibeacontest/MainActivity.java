package com.example.ibeacontest;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashSet;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    TextView textView;

    Button button1;

    String res = "";
    Button button2;
    String minorText = "";

    String TAG = "In main ";

    String horizon_index = "";
    String vertical_index = "";

    HashSet <Integer> devicesSet = new HashSet <>();

    HashSet <iBeaconClass.iBeacon> iBeaconHashSet = new HashSet <>();

    private ScanCallback scanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {

            byte[] scanData = result.getScanRecord().getBytes();

            int major = 0;
            int minor = 0;
            if (scanData[5] == 0x4C && scanData[6] == 0x00 && scanData[7] == 0x02 && scanData[8] == 0x15) {
                iBeaconClass.iBeacon myiBeacon = new iBeaconClass.iBeacon();

                byte[] uuidValue = new byte[16];
                System.arraycopy(scanData, 9, uuidValue, 0, 16);
                String uuid = "";
                String hexStr = CYUtils.Bytes2HexString(uuidValue);
                uuid = hexStr.substring(0, 8);
                uuid += "-";
                uuid += hexStr.substring(8, 12);
                uuid += "-";
                uuid += hexStr.substring(12, 16);
                uuid += "-";
                uuid += hexStr.substring(16, 20);
                uuid += "-";
                uuid += hexStr.substring(20, 32);
                major = CYUtils.byteToInt(scanData[25], scanData[26]);
                minor = CYUtils.byteToInt(scanData[27], scanData[28]);
                int measuredPower = scanData[29];
                Log.e(TAG, "onScanResult :minor :" + minor);
                Log.e(TAG, "onScanResult: uuid :" + uuid);
                Log.e(TAG, "onScanResult: RSSI :" + result.getRssi());
                myiBeacon.bluetoothAddress = result.getDevice().toString();
                myiBeacon.major = major;
                myiBeacon.minor = minor;
                myiBeacon.proximityUuid = uuid;
                myiBeacon.rssi = result.getRssi();
                myiBeacon.txPower = result.getTxPower();
                iBeaconHashSet.add(myiBeacon);
                if (minor == 542 || minor == 288) {
                    minorText = minorText + "devices :" + minor + " rssi :" + result.getRssi() + "\n total devices : " + iBeaconHashSet.size() + "\n";
                }
                textView.setText(minorText);
                devicesSet.add(minor);
            }
            //Log.e("TAG", "onScanResult :scanData " + iBeaconClass.bytesToHexString(scanData));

            //textView.setText("device: " + minor + " rssi:" + result.getRssi() + "\n total devices :" + devicesSet.size());


            //Log.e("TAG", "onScanResult :device: " + result.getDevice() + " rssi:" + result.getRssi());
        }

        @Override
        public void onBatchScanResults(List <ScanResult> results) {
            super.onBatchScanResults(results);
            Log.e(TAG, "onBatchScanResults: " + results.size());
        }

        @Override
        public void onScanFailed(int errorCode) {
            super.onScanFailed(errorCode);


        }


    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.e(TAG, "onCreate: 蓝牙设备收集app正在工作");
        getPermission();
        System.out.println("蓝牙设备收集app正在工作");

        textView = (TextView) findViewById(R.id.textView);
        textView.setMovementMethod(ScrollingMovementMethod.getInstance());
        //检测手机是否支持蓝牙，并获取mBluetoothAdapter对象
        final BluetoothManager bluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);

        final BluetoothAdapter mBluetoothAdapter = bluetoothManager.getAdapter();

        if (!getPackageManager().hasSystemFeature(
                PackageManager.FEATURE_BLUETOOTH_LE)) {
            Toast.makeText(this, "bluetooth device is not supported", Toast.LENGTH_SHORT)
                    .show();
            finish();
        }

        final BluetoothLeScanner mBluetoothLeScanner = mBluetoothAdapter.getBluetoothLeScanner();


        if (mBluetoothAdapter == null) {
            Toast.makeText(this, "bluetooth device is not supported",
                    Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        mBluetoothAdapter.enable();


        button1 = (Button) findViewById(R.id.button_1);
        //开始扫描周围的BLE设备
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //mBluetoothLeScanner.stopScan(scanCallback);

                TextView horizon_textview = (TextView) findViewById(R.id.horizontal_coordinates);
                horizon_index = horizon_textview.getText().toString();
                TextView vertical_textview = (TextView) findViewById(R.id.vertical_coordinates);
                vertical_index = vertical_textview.getText().toString();

                if (horizon_index.equals("") || horizon_index == null || vertical_index.equals("") || vertical_index == null) {
                    showInfo("坐标点的信息获取错误，请检查");
                    return;
                }

                Log.e(TAG, "onClick: 坐标内容似乎没什么问题 开始扫描周围的BLE设备");


                mBluetoothLeScanner.startScan(scanCallback);
                //mBluetoothAdapter.startLeScan(mLeScanCallback);
            }
        });

        button2 = (Button) findViewById(R.id.button_2);

        //停止扫描周围的BLE设备
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mBluetoothLeScanner.stopScan(scanCallback);

                Log.e(TAG, "onClick: 停止扫描周围的BLE设备");
            }
        });
    }

    private final int ACCESS_LOCATION = 1;

    private void getPermission() {
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.M) {
            int permissionCheck = 0;
            permissionCheck = this.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION);
            permissionCheck += this.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION);

            if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
                //未获得权限
                this.requestPermissions( // 请求授权
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION},
                        ACCESS_LOCATION);// 自定义常量,任意整型
            }
        }
    }

    /**
     * 请求权限的结果回调。每次调用 requestpermissions（string[]，int）时都会调用此方法。
     *
     * @param requestCode  传入的请求代码
     * @param permissions  传入permissions的要求
     * @param grantResults 相应权限的授予结果:PERMISSION_GRANTED 或 PERMISSION_DENIED
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case ACCESS_LOCATION:
                if (hasAllPermissionGranted(grantResults)) {
                    Log.i(TAG, "onRequestPermissionsResult: 用户允许权限");
                } else {
                    Log.i(TAG, "onRequestPermissionsResult: 拒绝搜索设备权限");
                }
                break;
        }
    }

    private boolean hasAllPermissionGranted(int[] grantResults) {
        for (int grantResult : grantResults) {
            if (grantResult == PackageManager.PERMISSION_DENIED) {
                return false;
            }
        }
        return true;
    }

    public void showInfo(String info) {
        Toast toast = Toast.makeText(this, info, Toast.LENGTH_LONG);
    }

}